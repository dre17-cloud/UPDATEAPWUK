package client.gui;

import server.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class AssignShipmentFrame extends JFrame {

    private JComboBox<String> shipmentBox, vehicleBox;

    public AssignShipmentFrame() {

        setTitle("Assign Shipment to Vehicle");
        setSize(420, 260);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10,10,10,10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Shipment Label
        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Select Shipment:"), gbc);

        shipmentBox = new JComboBox<>();
        loadShipments();
        gbc.gridx = 1;
        add(shipmentBox, gbc);

        // Vehicle Label
        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Select Vehicle:"), gbc);

        vehicleBox = new JComboBox<>();
        loadVehicles();
        gbc.gridx = 1;
        add(vehicleBox, gbc);

        // Button
        JButton assignBtn = new JButton("Assign");
        gbc.gridx = 1; gbc.gridy = 2;
        add(assignBtn, gbc);

        assignBtn.addActionListener(e -> assignShipment());
    }

    private void loadShipments() {
        shipmentBox.addItem("Select");

        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "SELECT `Tracking Number` FROM baseshipment";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                shipmentBox.addItem(rs.getString("Tracking Number"));
            }

        } catch (Exception e) {
            shipmentBox.addItem("Error");
        }
    }

    private void loadVehicles() {
        vehicleBox.addItem("Select");

        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "SELECT `Vehicle ID` FROM vehicle";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                vehicleBox.addItem(rs.getString("Vehicle ID"));
            }

        } catch (Exception e) {
            vehicleBox.addItem("Error");
        }
    }

    private void assignShipment() {

        if (shipmentBox.getSelectedIndex() <= 0 || vehicleBox.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this, "No shipment or vehicle selected!");
            return;
        }

        String shipment = shipmentBox.getSelectedItem().toString();
        String vehicle = vehicleBox.getSelectedItem().toString();

        try {
            Connection conn = DatabaseConnection.getConnection();

            String sql = "UPDATE vehicle SET `Assigned Shipments`=? WHERE `Vehicle ID`=?";
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, shipment);
            ps.setString(2, vehicle);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Shipment assigned successfully!");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
        }
    }
}
