package client.gui;

import server.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class ShipmentToVechicle extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JComboBox<String> shipmentList;
    private JComboBox<String> vehicleList;
    private JLabel statusMessage;

    public ShipmentToVechicle() {
        setSize(600, 400);
        setTitle("Assign Shipment To Vehicle");
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Assign Shipment To Vehicle");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(title, gbc);

        // =============================
        // SHIPMENT DROPDOWN
        // =============================
        gbc.gridwidth = 1;
        gbc.gridy = 1; gbc.gridx = 0;
        add(new JLabel("Select Shipment"), gbc);

        shipmentList = new JComboBox<>();
        gbc.gridx = 1;
        add(shipmentList, gbc);

        loadAvailableShipments();

        // =============================
        // VEHICLE DROPDOWN
        // =============================
        gbc.gridy = 2; gbc.gridx = 0;
        add(new JLabel("Select Vehicle"), gbc);

        vehicleList = new JComboBox<>();
        gbc.gridx = 1;
        add(vehicleList, gbc);

        loadVehicles();

        // =============================
        // STATUS MESSAGE
        // =============================
        statusMessage = new JLabel(" ");
        gbc.gridy = 3; gbc.gridx = 0; gbc.gridwidth = 2;
        add(statusMessage, gbc);

        // =============================
        // ASSIGN BUTTON
        // =============================
        JButton assignBtn = new JButton("Assign Shipment");
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        add(assignBtn, gbc);

        assignBtn.addActionListener(this::assignShipment);

        setVisible(true);
    }

    // LOAD ONLY SHIPMENTS THAT ARE NOT ASSIGNED
    private void loadAvailableShipments() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql =
                    "SELECT `Tracking Number` FROM baseshipment WHERE Status = 'Processed'";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                shipmentList.addItem(rs.getString("Tracking Number"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // LOAD ALL VEHICLES
    private void loadVehicles() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "SELECT `Vehicle ID` FROM vehicle";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                vehicleList.addItem(rs.getString("Vehicle ID"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // ASSIGN SHIPMENT TO VEHICLE
    private void assignShipment(ActionEvent e) {
        String shipment = (String) shipmentList.getSelectedItem();
        String vehicle = (String) vehicleList.getSelectedItem();

        if (shipment == null || vehicle == null) {
            statusMessage.setText("Please select both a shipment and vehicle.");
            return;
        }

        try {
            Connection conn = DatabaseConnection.getConnection();

            // =============================
            // 1. UPDATE SHIPMENT TABLE
            // =============================
            String updateShipmentSql =
                    "UPDATE baseshipment SET Status = 'In Vehicle' WHERE `Tracking Number` = ?";

            PreparedStatement ps1 = conn.prepareStatement(updateShipmentSql);
            ps1.setString(1, shipment);
            ps1.executeUpdate();

            // =============================
            // 2. UPDATE VEHICLE TABLE
            // =============================
            String getAssignedSql =
                    "SELECT `Assigned Shipments` FROM vehicle WHERE `Vehicle ID` = ?";

            PreparedStatement ps2 = conn.prepareStatement(getAssignedSql);
            ps2.setString(1, vehicle);
            ResultSet rs = ps2.executeQuery();

            String newList = shipment;

            if (rs.next()) {
                String assigned = rs.getString("Assigned Shipments");
                if (assigned != null && !assigned.isBlank()) {
                    newList = assigned + ", " + shipment;
                }
            }

            String updateVehicleSql =
                    "UPDATE vehicle SET `Assigned Shipments` = ? WHERE `Vehicle ID` = ?";

            PreparedStatement ps3 = conn.prepareStatement(updateVehicleSql);
            ps3.setString(1, newList);
            ps3.setString(2, vehicle);
            ps3.executeUpdate();

            statusMessage.setText("Shipment " + shipment + " assigned to vehicle " + vehicle);

        } catch (Exception ex) {
            ex.printStackTrace();
            statusMessage.setText("Error occurred during assignment.");
        }
    }

    public static void main(String[] args) {
        new ShipmentToVechicle();
    }
}
